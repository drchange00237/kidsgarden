# Kids Video Streaming Platform

Une plateforme de streaming vidéo locale conçue pour les enfants et les préadolescents avec des interfaces adaptées à chaque groupe d'âge.

## 🚀 Déploiement Local et Accès Réseau

### Installation

```bash
npm install
```

### Démarrage en mode développement (accès réseau)

```bash
npm run dev
```

### Démarrage en mode production

```bash
npm run start
```

### Accès depuis d'autres appareils

Une fois l'application démarrée, elle sera accessible sur :

- **Ordinateur local** : `http://localhost:3000`
- **Autres appareils du réseau** : `http://[VOTRE_IP]:3000`

Pour connaître votre adresse IP :

#### Windows
```cmd
ipconfig
```
Cherchez "Adresse IPv4" dans la section de votre connexion réseau.

#### macOS/Linux
```bash
ifconfig
```
ou
```bash
ip addr show
```

### Exemples d'accès réseau

Si votre IP est `192.168.1.100`, l'application sera accessible sur :
- TV connectée : `http://192.168.1.100:3000`
- Tablette : `http://192.168.1.100:3000`
- Autre PC : `http://192.168.1.100:3000`
- Smartphone : `http://192.168.1.100:3000`

## 📱 Compatibilité Multi-Appareils

L'application est optimisée pour :
- **Ordinateurs** (Windows, macOS, Linux)
- **Tablettes** (iPad, Android)
- **Smart TV** avec navigateur web
- **Smartphones** (iOS, Android)
- **Consoles de jeu** avec navigateur

## 🎮 Contrôles

### Navigation Clavier (TV/PC)
- **Flèches** : Navigation dans la grille
- **Entrée** : Sélectionner/Lire
- **Échap** : Retour/Déconnexion
- **Espace** : Lecture/Pause (dans le lecteur)
- **F** : Plein écran
- **M** : Muet/Son

### Navigation Tactile (Tablette/Smartphone)
- Interface tactile optimisée
- Gestes de balayage
- Contrôles tactiles du lecteur vidéo

## 👥 Comptes de Démonstration

### Mode Enfants
- **Administrateur** : `monitor` / `kids123`
- **Utilisateur** : `child` / `play123`

### Mode Préadolescents
- **Administrateur** : `admin` / `teen123`
- **Utilisateur** : `preteen` / `cool123`

## 🔧 Configuration Réseau

### Pare-feu
Assurez-vous que le port 3000 est ouvert dans votre pare-feu :

#### Windows
```cmd
netsh advfirewall firewall add rule name="Kids Video Platform" dir=in action=allow protocol=TCP localport=3000
```

#### macOS
Le pare-feu macOS autorise généralement les connexions entrantes pour les applications.

#### Linux (UFW)
```bash
sudo ufw allow 3000
```

### Routeur
Si vous voulez accéder depuis l'extérieur de votre réseau local, configurez la redirection de port sur votre routeur (port 3000 vers l'IP de votre ordinateur).

## 📺 Optimisation pour TV

L'interface s'adapte automatiquement aux grands écrans :
- Navigation optimisée pour télécommande
- Texte et boutons plus grands
- Contraste amélioré pour la visibilité à distance
- Support du mode plein écran

## 🔒 Sécurité Réseau Local

- L'application fonctionne uniquement sur votre réseau local
- Aucune donnée n'est envoyée sur Internet
- Les vidéos sont stockées localement
- Accès sécurisé par authentification

## 🛠️ Dépannage

### L'application n'est pas accessible depuis d'autres appareils

1. Vérifiez que votre pare-feu autorise le port 3000
2. Assurez-vous que tous les appareils sont sur le même réseau WiFi
3. Vérifiez l'adresse IP de votre ordinateur
4. Redémarrez l'application avec `npm run dev`

### Problèmes de lecture vidéo sur TV

1. Utilisez des formats vidéo compatibles (MP4 H.264)
2. Vérifiez la bande passante de votre réseau WiFi
3. Réduisez la qualité vidéo si nécessaire

### Performance lente

1. Fermez les autres applications consommatrices de réseau
2. Rapprochez les appareils du routeur WiFi
3. Utilisez une connexion Ethernet si possible

## 📋 Formats Vidéo Supportés

- **MP4** (H.264/H.265) - Recommandé
- **WebM** (VP8/VP9)
- **OGG** (Theora)
- **MOV** (QuickTime)
- **AVI** (avec codecs compatibles)

## 🎯 Utilisation Recommandée

1. **Démarrez l'application** sur un ordinateur central
2. **Connectez tous les appareils** au même réseau WiFi
3. **Accédez via navigateur** sur chaque appareil
4. **Gérez le contenu** depuis le panneau admin
5. **Profitez** du streaming sur tous vos écrans !