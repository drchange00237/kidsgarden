import React, { useState, useEffect } from 'react';
import { Video, User, AppState } from './types';
import { getTheme } from './themes';
import { videoService } from './videoService';
import LoginScreen from './components/LoginScreen';
import VideoGrid from './components/VideoGrid';
import VideoPlayer from './components/VideoPlayer';
import AdminPanel from './components/AdminPanel';

function App() {
  const [appState, setAppState] = useState<AppState>('login');
  const [user, setUser] = useState<User | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);

  // Load videos from localStorage on mount
  useEffect(() => {
    const savedVideos = videoService.getVideos();
    setVideos(savedVideos);
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setAppState('videos');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentVideo(null);
    setAppState('login');
  };

  const handleVideoSelect = (video: Video) => {
    setCurrentVideo(video);
    setAppState('player');
  };

  const handleVideoChange = (video: Video) => {
    setCurrentVideo(video);
  };

  const handleAdminAccess = () => {
    setAppState('admin');
  };

  const handleBackToVideos = () => {
    setAppState('videos');
  };

  const handleClosePlayer = () => {
    setCurrentVideo(null);
    setAppState('videos');
  };

  const handleVideosUpdate = () => {
    const updatedVideos = videoService.getVideos();
    setVideos(updatedVideos);
  };

  // Get theme based on user mode
  const theme = user ? getTheme(user.mode) : getTheme('kids');

  if (appState === 'login') {
    return <LoginScreen onLogin={handleLogin} />;
  }

  if (appState === 'admin' && user) {
    return (
      <AdminPanel
        user={user}
        theme={theme}
        onBack={handleBackToVideos}
        onVideosUpdate={handleVideosUpdate}
      />
    );
  }

  if (appState === 'player' && currentVideo && user) {
    return (
      <VideoPlayer
        video={currentVideo}
        videos={videos}
        theme={theme}
        autoplay={true}
        onClose={handleClosePlayer}
        onVideoChange={handleVideoChange}
      />
    );
  }

  if (appState === 'videos' && user) {
    return (
      <VideoGrid
        videos={videos}
        user={user}
        theme={theme}
        onVideoSelect={handleVideoSelect}
        onAdminAccess={handleAdminAccess}
        onLogout={handleLogout}
      />
    );
  }

  return null;
}

export default App;