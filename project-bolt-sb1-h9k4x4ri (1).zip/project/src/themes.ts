import { Theme } from './types';

export const kidsTheme: Theme = {
  name: 'kids',
  colors: {
    primary: '#8B5CF6', // Purple
    secondary: '#F59E0B', // Amber
    accent: '#EC4899', // Pink
    background: '#FEF7FF', // Very light purple
    surface: '#FFFFFF',
    text: '#1F2937',
    textSecondary: '#6B7280',
  },
  fonts: {
    heading: '"Comic Sans MS", cursive, system-ui',
    body: '"Comic Sans MS", cursive, system-ui',
  },
};

export const preteenTheme: Theme = {
  name: 'preteen',
  colors: {
    primary: '#6B7280', // Gray
    secondary: '#F97316', // Orange
    accent: '#3B82F6', // Blue
    background: '#F9FAFB', // Light gray
    surface: '#FFFFFF',
    text: '#111827',
    textSecondary: '#6B7280',
  },
  fonts: {
    heading: 'Inter, system-ui, sans-serif',
    body: 'Inter, system-ui, sans-serif',
  },
};

export const getTheme = (mode: 'kids' | 'preteen'): Theme => {
  return mode === 'kids' ? kidsTheme : preteenTheme;
};