import React, { useState, useEffect, useRef } from 'react';
import { Video, User, Theme } from '../types';
import { Play, Settings, Plus, Grid, List } from 'lucide-react';
import { truncateText, formatDuration } from '../utils';

interface VideoGridProps {
  videos: Video[];
  user: User;
  theme: Theme;
  onVideoSelect: (video: Video) => void;
  onAdminAccess: () => void;
  onLogout: () => void;
}

const VideoGrid: React.FC<VideoGridProps> = ({
  videos,
  user,
  theme,
  onVideoSelect,
  onAdminAccess,
  onLogout,
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (videos.length === 0) return;

      switch (e.key) {
        case 'ArrowRight':
          e.preventDefault();
          if (viewMode === 'grid') {
            setSelectedIndex(prev => Math.min(prev + 1, videos.length - 1));
          }
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (viewMode === 'grid') {
            setSelectedIndex(prev => Math.max(prev - 1, 0));
          }
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (viewMode === 'grid') {
            const itemsPerRow = Math.floor((gridRef.current?.offsetWidth || 1200) / 320);
            setSelectedIndex(prev => Math.min(prev + itemsPerRow, videos.length - 1));
          } else {
            setSelectedIndex(prev => Math.min(prev + 1, videos.length - 1));
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (viewMode === 'grid') {
            const itemsPerRow = Math.floor((gridRef.current?.offsetWidth || 1200) / 320);
            setSelectedIndex(prev => Math.max(prev - itemsPerRow, 0));
          } else {
            setSelectedIndex(prev => Math.max(prev - 1, 0));
          }
          break;
        case 'Enter':
          e.preventDefault();
          if (videos[selectedIndex]) {
            onVideoSelect(videos[selectedIndex]);
          }
          break;
        case 'Escape':
          e.preventDefault();
          onLogout();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [videos, selectedIndex, viewMode, onVideoSelect, onLogout]);

  const themeTitle = user.mode === 'kids' 
    ? 'Kid\'s Video Land ICC Ngaoundere'
    : 'Preteen ICC Video Land';

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: theme.colors.background,
        fontFamily: theme.fonts.body 
      }}
    >
      {/* Header */}
      <header 
        className="sticky top-0 z-10 backdrop-blur-md border-b shadow-sm"
        style={{ 
          backgroundColor: theme.colors.surface + 'E6',
          borderColor: theme.colors.primary + '20'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 
              className="text-2xl font-bold"
              style={{ 
                color: theme.colors.primary,
                fontFamily: theme.fonts.heading 
              }}
            >
              {themeTitle}
            </h1>
            
            <div className="flex items-center space-x-4">
              {/* View Mode Toggle */}
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'grid'
                      ? 'bg-white shadow-sm text-gray-800'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                  title="Grid View"
                >
                  <Grid size={20} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'list'
                      ? 'bg-white shadow-sm text-gray-800'
                      : 'text-gray-600 hover:text-gray-800'
                  }`}
                  title="List View"
                >
                  <List size={20} />
                </button>
              </div>

              {user.isAdmin && (
                <button
                  onClick={onAdminAccess}
                  className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:shadow-lg"
                  style={{ backgroundColor: theme.colors.secondary }}
                >
                  <Settings size={20} />
                  <span>Admin</span>
                </button>
              )}

              <button
                onClick={onLogout}
                className="px-4 py-2 rounded-lg font-medium transition-colors border"
                style={{ 
                  borderColor: theme.colors.primary,
                  color: theme.colors.primary
                }}
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {videos.length === 0 ? (
          <div className="text-center py-16">
            <div 
              className="w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6"
              style={{ backgroundColor: theme.colors.primary + '20' }}
            >
              <Play 
                size={48} 
                style={{ color: theme.colors.primary }} 
              />
            </div>
            <h2 
              className="text-2xl font-bold mb-4"
              style={{ color: theme.colors.text }}
            >
              No Videos Available
            </h2>
            <p 
              className="text-lg mb-8"
              style={{ color: theme.colors.textSecondary }}
            >
              {user.isAdmin 
                ? 'Add some videos to get started!' 
                : 'Ask an administrator to add some videos.'}
            </p>
            {user.isAdmin && (
              <button
                onClick={onAdminAccess}
                className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg text-white font-medium transition-all duration-200 hover:shadow-lg"
                style={{ backgroundColor: theme.colors.primary }}
              >
                <Plus size={20} />
                <span>Add Videos</span>
              </button>
            )}
          </div>
        ) : (
          <div ref={gridRef}>
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {videos.map((video, index) => (
                  <VideoCard
                    key={video.id}
                    video={video}
                    theme={theme}
                    isSelected={selectedIndex === index}
                    onClick={() => onVideoSelect(video)}
                    onFocus={() => setSelectedIndex(index)}
                  />
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {videos.map((video, index) => (
                  <VideoListItem
                    key={video.id}
                    video={video}
                    theme={theme}
                    isSelected={selectedIndex === index}
                    onClick={() => onVideoSelect(video)}
                    onFocus={() => setSelectedIndex(index)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {videos.length > 0 && (
          <div className="mt-8 text-center">
            <p 
              className="text-sm"
              style={{ color: theme.colors.textSecondary }}
            >
              Use arrow keys to navigate • Enter to play • Escape to logout
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

interface VideoCardProps {
  video: Video;
  theme: Theme;
  isSelected: boolean;
  onClick: () => void;
  onFocus: () => void;
}

const VideoCard: React.FC<VideoCardProps> = ({
  video,
  theme,
  isSelected,
  onClick,
  onFocus,
}) => {
  return (
    <div
      className={`group cursor-pointer rounded-xl overflow-hidden transition-all duration-300 transform ${
        isSelected 
          ? 'ring-4 scale-105 shadow-2xl' 
          : 'hover:scale-105 hover:shadow-xl'
      }`}
      style={{ 
        backgroundColor: theme.colors.surface,
        ...(isSelected && { 
          ringColor: theme.colors.primary,
          boxShadow: `0 20px 25px -5px ${theme.colors.primary}40, 0 10px 10px -5px ${theme.colors.primary}20`
        })
      }}
      onClick={onClick}
      onMouseEnter={onFocus}
      tabIndex={0}
      role="button"
      aria-label={`Play ${video.title}`}
    >
      <div className="aspect-video relative overflow-hidden">
        {video.thumbnail ? (
          <img
            src={video.thumbnail}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
        ) : (
          <div 
            className="w-full h-full flex items-center justify-center"
            style={{ backgroundColor: theme.colors.primary + '20' }}
          >
            <Play 
              size={48} 
              style={{ color: theme.colors.primary }} 
            />
          </div>
        )}
        
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
          <div 
            className="w-16 h-16 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform scale-75 group-hover:scale-100 transition-all duration-300"
            style={{ backgroundColor: theme.colors.primary }}
          >
            <Play size={24} className="text-white ml-1" />
          </div>
        </div>

        {video.duration && (
          <div className="absolute bottom-2 right-2 px-2 py-1 bg-black bg-opacity-75 text-white text-xs rounded">
            {formatDuration(video.duration)}
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 
          className="font-semibold text-lg mb-2 line-clamp-2"
          style={{ color: theme.colors.text }}
        >
          {truncateText(video.title, 50)}
        </h3>
        {video.description && (
          <p 
            className="text-sm line-clamp-3"
            style={{ color: theme.colors.textSecondary }}
          >
            {truncateText(video.description, 100)}
          </p>
        )}
      </div>
    </div>
  );
};

interface VideoListItemProps {
  video: Video;
  theme: Theme;
  isSelected: boolean;
  onClick: () => void;
  onFocus: () => void;
}

const VideoListItem: React.FC<VideoListItemProps> = ({
  video,
  theme,
  isSelected,
  onClick,
  onFocus,
}) => {
  return (
    <div
      className={`group cursor-pointer rounded-lg p-4 transition-all duration-200 ${
        isSelected ? 'ring-2 shadow-lg' : 'hover:shadow-md'
      }`}
      style={{ 
        backgroundColor: theme.colors.surface,
        ...(isSelected && { ringColor: theme.colors.primary })
      }}
      onClick={onClick}
      onMouseEnter={onFocus}
      tabIndex={0}
      role="button"
      aria-label={`Play ${video.title}`}
    >
      <div className="flex items-center space-x-4">
        <div className="w-32 h-20 rounded-lg overflow-hidden flex-shrink-0">
          {video.thumbnail ? (
            <img
              src={video.thumbnail}
              alt={video.title}
              className="w-full h-full object-cover"
            />
          ) : (
            <div 
              className="w-full h-full flex items-center justify-center"
              style={{ backgroundColor: theme.colors.primary + '20' }}
            >
              <Play 
                size={24} 
                style={{ color: theme.colors.primary }} 
              />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h3 
            className="font-semibold text-lg mb-1"
            style={{ color: theme.colors.text }}
          >
            {video.title}
          </h3>
          {video.description && (
            <p 
              className="text-sm line-clamp-2"
              style={{ color: theme.colors.textSecondary }}
            >
              {video.description}
            </p>
          )}
          {video.duration && (
            <p 
              className="text-xs mt-1"
              style={{ color: theme.colors.textSecondary }}
            >
              Duration: {formatDuration(video.duration)}
            </p>
          )}
        </div>

        <div 
          className="w-12 h-12 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ backgroundColor: theme.colors.primary + '20' }}
        >
          <Play 
            size={20} 
            style={{ color: theme.colors.primary }} 
          />
        </div>
      </div>
    </div>
  );
};

export default VideoGrid;