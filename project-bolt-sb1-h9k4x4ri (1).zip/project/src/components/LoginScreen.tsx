import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { Video, Lock, Users } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedMode, setSelectedMode] = useState<'kids' | 'preteen'>('kids');
  const [error, setError] = useState('');

  // Default credentials
  const defaultUsers: User[] = [
    { username: 'monitor', password: 'kids123', mode: 'kids', isAdmin: true },
    { username: 'child', password: 'play123', mode: 'kids', isAdmin: false },
    { username: 'admin', password: 'teen123', mode: 'preteen', isAdmin: true },
    { username: 'preteen', password: 'cool123', mode: 'preteen', isAdmin: false },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = defaultUsers.find(u => 
      u.username === username && 
      u.password === password && 
      u.mode === selectedMode
    );

    if (user) {
      onLogin(user);
    } else {
      setError('Invalid credentials or wrong mode selected');
    }
  };

  const modeStyles = {
    kids: {
      background: 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)',
      accent: '#F59E0B',
      title: 'Kid\'s Video Land ICC Ngaoundere',
      font: '"Comic Sans MS", cursive',
    },
    preteen: {
      background: 'linear-gradient(135deg, #6B7280 0%, #F97316 100%)',
      accent: '#3B82F6',
      title: 'Preteen ICC Video Land',
      font: 'Inter, system-ui, sans-serif',
    },
  };

  const currentStyle = modeStyles[selectedMode];

  useEffect(() => {
    setUsername('');
    setPassword('');
    setError('');
  }, [selectedMode]);

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: currentStyle.background }}
    >
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md transform transition-all duration-500">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div 
              className="p-4 rounded-full"
              style={{ backgroundColor: currentStyle.accent + '20' }}
            >
              <Video 
                size={48} 
                style={{ color: currentStyle.accent }} 
              />
            </div>
          </div>
          <h1 
            className="text-2xl font-bold text-gray-800 mb-2"
            style={{ fontFamily: currentStyle.font }}
          >
            {currentStyle.title}
          </h1>
          <p className="text-gray-600">Welcome! Please sign in to continue</p>
        </div>

        {/* Mode Selection */}
        <div className="flex bg-gray-100 rounded-lg p-1 mb-6">
          <button
            type="button"
            onClick={() => setSelectedMode('kids')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
              selectedMode === 'kids'
                ? 'bg-purple-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Kids Mode
          </button>
          <button
            type="button"
            onClick={() => setSelectedMode('preteen')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
              selectedMode === 'preteen'
                ? 'bg-orange-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Preteen Mode
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Users size={16} className="inline mr-2" />
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your username"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Lock size={16} className="inline mr-2" />
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your password"
              required
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 px-4 rounded-lg text-white font-medium transition-all duration-200 transform hover:scale-105 hover:shadow-lg"
            style={{ backgroundColor: currentStyle.accent }}
          >
            Sign In
          </button>
        </form>

        {/* Demo Credentials */}
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Demo Credentials:</h3>
          <div className="text-xs text-gray-600 space-y-1">
            <div><strong>Kids Mode:</strong> monitor/kids123 (admin) | child/play123</div>
            <div><strong>Preteen Mode:</strong> admin/teen123 (admin) | preteen/cool123</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;