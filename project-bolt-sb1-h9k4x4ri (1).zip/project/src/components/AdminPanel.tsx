import React, { useState, useEffect, useRef } from 'react';
import { Video, User, Theme } from '../types';
import { videoService } from '../videoService';
import { 
  ArrowLeft, 
  Plus, 
  Upload, 
  Link as LinkIcon, 
  Edit3, 
  Trash2, 
  Save, 
  X,
  Video as VideoIcon,
  ImageIcon,
  FileVideo,
  Globe
} from 'lucide-react';
import { isValidVideoUrl, formatDuration } from '../utils';

interface AdminPanelProps {
  user: User;
  theme: Theme;
  onBack: () => void;
  onVideosUpdate: () => void;
}

interface VideoForm {
  title: string;
  description: string;
  url: string;
  thumbnail?: string;
  file?: File;
  thumbnailFile?: File;
}

const AdminPanel: React.FC<AdminPanelProps> = ({
  user,
  theme,
  onBack,
  onVideosUpdate,
}) => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [videoForm, setVideoForm] = useState<VideoForm>({
    title: '',
    description: '',
    url: '',
  });
  const [uploadMethod, setUploadMethod] = useState<'url' | 'file'>('url');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = () => {
    const loadedVideos = videoService.getVideos();
    setVideos(loadedVideos);
  };

  const resetForm = () => {
    setVideoForm({
      title: '',
      description: '',
      url: '',
    });
    setUploadMethod('url');
    setEditingVideo(null);
  };

  const handleAddVideo = () => {
    resetForm();
    setShowAddModal(true);
  };

  const handleEditVideo = (video: Video) => {
    setVideoForm({
      title: video.title,
      description: video.description,
      url: video.url,
      thumbnail: video.thumbnail,
    });
    setUploadMethod(video.url.startsWith('blob:') ? 'file' : 'url');
    setEditingVideo(video);
    setShowAddModal(true);
  };

  const handleDeleteVideo = (videoId: string) => {
    if (confirm('Are you sure you want to delete this video?')) {
      videoService.deleteVideo(videoId);
      loadVideos();
      onVideosUpdate();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let videoUrl = videoForm.url;
      let thumbnail = videoForm.thumbnail;

      // Handle file upload
      if (uploadMethod === 'file' && videoForm.file) {
        videoUrl = URL.createObjectURL(videoForm.file);
        
        // Generate thumbnail if not provided
        if (!videoForm.thumbnailFile && !thumbnail) {
          try {
            thumbnail = await videoService.generateThumbnail(videoForm.file);
          } catch (error) {
            console.warn('Failed to generate thumbnail:', error);
          }
        }
      }

      // Handle custom thumbnail upload
      if (videoForm.thumbnailFile) {
        thumbnail = URL.createObjectURL(videoForm.thumbnailFile);
      }

      const videoData = {
        title: videoForm.title.trim(),
        description: videoForm.description.trim(),
        url: videoUrl,
        thumbnail,
      };

      if (editingVideo) {
        videoService.updateVideo(editingVideo.id, videoData);
      } else {
        videoService.addVideo(videoData);
      }

      loadVideos();
      onVideosUpdate();
      setShowAddModal(false);
      resetForm();
    } catch (error) {
      console.error('Error saving video:', error);
      alert('Failed to save video. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileSelect = (files: FileList | null) => {
    if (files && files[0]) {
      const file = files[0];
      if (file.type.startsWith('video/')) {
        setVideoForm(prev => ({ ...prev, file }));
      } else {
        alert('Please select a valid video file.');
      }
    }
  };

  const handleThumbnailSelect = (files: FileList | null) => {
    if (files && files[0]) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        setVideoForm(prev => ({ ...prev, thumbnailFile: file }));
      } else {
        alert('Please select a valid image file.');
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files);
    }
  };

  const isFormValid = () => {
    if (!videoForm.title.trim()) return false;
    
    if (uploadMethod === 'url') {
      return videoForm.url.trim() && isValidVideoUrl(videoForm.url);
    } else {
      return !!videoForm.file || !!editingVideo;
    }
  };

  const themeTitle = user.mode === 'kids' 
    ? 'Kid\'s Video Land - Admin Panel'
    : 'Preteen ICC Video Land - Admin Panel';

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: theme.colors.background,
        fontFamily: theme.fonts.body 
      }}
    >
      {/* Header */}
      <header 
        className="sticky top-0 z-10 backdrop-blur-md border-b shadow-sm"
        style={{ 
          backgroundColor: theme.colors.surface + 'E6',
          borderColor: theme.colors.primary + '20'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ArrowLeft size={20} />
                <span>Back to Videos</span>
              </button>
              <h1 
                className="text-2xl font-bold"
                style={{ 
                  color: theme.colors.primary,
                  fontFamily: theme.fonts.heading 
                }}
              >
                {themeTitle}
              </h1>
            </div>
            
            <button
              onClick={handleAddVideo}
              className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:shadow-lg"
              style={{ backgroundColor: theme.colors.primary }}
            >
              <Plus size={20} />
              <span>Add Video</span>
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {videos.length === 0 ? (
          <div className="text-center py-16">
            <div 
              className="w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6"
              style={{ backgroundColor: theme.colors.primary + '20' }}
            >
              <VideoIcon 
                size={48} 
                style={{ color: theme.colors.primary }} 
              />
            </div>
            <h2 
              className="text-2xl font-bold mb-4"
              style={{ color: theme.colors.text }}
            >
              No Videos Yet
            </h2>
            <p 
              className="text-lg mb-8"
              style={{ color: theme.colors.textSecondary }}
            >
              Start building your video library by adding your first video.
            </p>
            <button
              onClick={handleAddVideo}
              className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg text-white font-medium transition-all duration-200 hover:shadow-lg"
              style={{ backgroundColor: theme.colors.primary }}
            >
              <Plus size={20} />
              <span>Add Your First Video</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <div
                key={video.id}
                className="rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl"
                style={{ backgroundColor: theme.colors.surface }}
              >
                <div className="aspect-video relative overflow-hidden">
                  {video.thumbnail ? (
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div 
                      className="w-full h-full flex items-center justify-center"
                      style={{ backgroundColor: theme.colors.primary + '20' }}
                    >
                      <VideoIcon 
                        size={48} 
                        style={{ color: theme.colors.primary }} 
                      />
                    </div>
                  )}
                </div>

                <div className="p-4">
                  <h3 
                    className="font-semibold text-lg mb-2 line-clamp-2"
                    style={{ color: theme.colors.text }}
                  >
                    {video.title}
                  </h3>
                  {video.description && (
                    <p 
                      className="text-sm mb-4 line-clamp-3"
                      style={{ color: theme.colors.textSecondary }}
                    >
                      {video.description}
                    </p>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleEditVideo(video)}
                        className="p-2 rounded-lg transition-colors hover:bg-gray-100"
                        title="Edit video"
                      >
                        <Edit3 size={16} style={{ color: theme.colors.primary }} />
                      </button>
                      <button
                        onClick={() => handleDeleteVideo(video.id)}
                        className="p-2 rounded-lg transition-colors hover:bg-red-50"
                        title="Delete video"
                      >
                        <Trash2 size={16} className="text-red-500" />
                      </button>
                    </div>
                    
                    <div className="text-xs text-gray-500">
                      {new Date(video.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Add/Edit Video Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div
            ref={modalRef}
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b px-6 py-4 rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold" style={{ color: theme.colors.text }}>
                  {editingVideo ? 'Edit Video' : 'Add New Video'}
                </h2>
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    resetForm();
                  }}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Upload Method Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Video Source
                </label>
                <div className="flex bg-gray-100 rounded-lg p-1">
                  <button
                    type="button"
                    onClick={() => setUploadMethod('url')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 flex items-center justify-center space-x-2 ${
                      uploadMethod === 'url'
                        ? 'bg-white shadow-md text-gray-800'
                        : 'text-gray-600 hover:text-gray-800'
                    }`}
                  >
                    <Globe size={16} />
                    <span>URL</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadMethod('file')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 flex items-center justify-center space-x-2 ${
                      uploadMethod === 'file'
                        ? 'bg-white shadow-md text-gray-800'
                        : 'text-gray-600 hover:text-gray-800'
                    }`}
                  >
                    <Upload size={16} />
                    <span>Upload</span>
                  </button>
                </div>
              </div>

              {/* Video URL or File Upload */}
              {uploadMethod === 'url' ? (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <LinkIcon size={16} className="inline mr-2" />
                    Video URL
                  </label>
                  <input
                    type="url"
                    value={videoForm.url}
                    onChange={(e) => setVideoForm(prev => ({ ...prev, url: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="https://example.com/video.mp4"
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Direct link to video file (.mp4, .webm, .ogg, .mov, .avi)
                  </p>
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Upload size={16} className="inline mr-2" />
                    Video File
                  </label>
                  <div
                    className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                      dragActive 
                        ? 'border-purple-500 bg-purple-50' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <FileVideo size={48} className="mx-auto text-gray-400 mb-4" />
                    {videoForm.file ? (
                      <div>
                        <p className="text-sm font-medium text-gray-900">{videoForm.file.name}</p>
                        <p className="text-xs text-gray-500">
                          {(videoForm.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    ) : editingVideo && !videoForm.file ? (
                      <div>
                        <p className="text-sm text-gray-600">Current video will be kept</p>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="mt-2 text-sm text-purple-600 hover:text-purple-700"
                        >
                          Choose new file
                        </button>
                      </div>
                    ) : (
                      <div>
                        <p className="text-sm text-gray-600 mb-2">
                          Drag and drop your video here, or click to browse
                        </p>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
                        >
                          Choose File
                        </button>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={(e) => handleFileSelect(e.target.files)}
                    className="hidden"
                  />
                </div>
              )}

              {/* Video Title */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Video Title *
                </label>
                <input
                  type="text"
                  value={videoForm.title}
                  onChange={(e) => setVideoForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Enter video title"
                  required
                />
              </div>

              {/* Video Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={videoForm.description}
                  onChange={(e) => setVideoForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-vertical"
                  rows={3}
                  placeholder="Enter video description (optional)"
                />
              </div>

              {/* Custom Thumbnail */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <ImageIcon size={16} className="inline mr-2" />
                  Custom Thumbnail (Optional)
                </label>
                <div className="flex items-center space-x-4">
                  {(videoForm.thumbnail || videoForm.thumbnailFile) && (
                    <div className="w-32 h-20 rounded-lg overflow-hidden border">
                      <img
                        src={videoForm.thumbnailFile 
                          ? URL.createObjectURL(videoForm.thumbnailFile)
                          : videoForm.thumbnail
                        }
                        alt="Thumbnail preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => thumbnailInputRef.current?.click()}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    {videoForm.thumbnail || videoForm.thumbnailFile ? 'Change' : 'Upload'} Thumbnail
                  </button>
                </div>
                <input
                  ref={thumbnailInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleThumbnailSelect(e.target.files)}
                  className="hidden"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {uploadMethod === 'file' 
                    ? 'If not provided, a thumbnail will be generated automatically'
                    : 'Upload a custom thumbnail image'
                  }
                </p>
              </div>

              {/* Form Actions */}
              <div className="flex items-center justify-end space-x-4 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    resetForm();
                  }}
                  className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!isFormValid() || isSubmitting}
                  className="flex items-center space-x-2 px-6 py-2 rounded-lg text-white font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{ backgroundColor: theme.colors.primary }}
                >
                  <Save size={16} />
                  <span>{isSubmitting ? 'Saving...' : editingVideo ? 'Update Video' : 'Add Video'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;