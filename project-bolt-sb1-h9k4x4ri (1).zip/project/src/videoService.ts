import { Video } from './types';

const STORAGE_KEY = 'kids_video_platform_videos';

export const videoService = {
  getVideos: (): Video[] => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  },

  saveVideos: (videos: Video[]): void => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(videos));
    } catch (error) {
      console.error('Failed to save videos:', error);
    }
  },

  addVideo: (video: Omit<Video, 'id' | 'createdAt'>): Video => {
    const newVideo: Video = {
      ...video,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    
    const videos = videoService.getVideos();
    videos.push(newVideo);
    videoService.saveVideos(videos);
    
    return newVideo;
  },

  updateVideo: (id: string, updates: Partial<Video>): void => {
    const videos = videoService.getVideos();
    const index = videos.findIndex(v => v.id === id);
    
    if (index !== -1) {
      videos[index] = { ...videos[index], ...updates };
      videoService.saveVideos(videos);
    }
  },

  deleteVideo: (id: string): void => {
    const videos = videoService.getVideos();
    const filtered = videos.filter(v => v.id !== id);
    videoService.saveVideos(filtered);
  },

  generateThumbnail: (videoFile: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }

      video.addEventListener('loadedmetadata', () => {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        video.currentTime = Math.min(video.duration * 0.1, 1);
      });

      video.addEventListener('seeked', () => {
        ctx.drawImage(video, 0, 0);
        const thumbnail = canvas.toDataURL('image/jpeg', 0.8);
        resolve(thumbnail);
        
        // Cleanup
        URL.revokeObjectURL(video.src);
      });

      video.addEventListener('error', () => {
        reject(new Error('Failed to load video'));
      });

      video.src = URL.createObjectURL(videoFile);
    });
  },
};