export interface Video {
  id: string;
  title: string;
  description: string;
  url: string;
  thumbnail?: string;
  duration?: number;
  createdAt: string;
}

export interface User {
  username: string;
  password: string;
  mode: 'kids' | 'preteen';
  isAdmin: boolean;
}

export interface Theme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
  };
  fonts: {
    heading: string;
    body: string;
  };
}

export type AppState = 'login' | 'videos' | 'admin' | 'player';